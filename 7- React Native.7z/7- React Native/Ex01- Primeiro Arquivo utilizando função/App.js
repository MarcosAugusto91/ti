import React from 'react';
import { View, Text } from 'react-native';

function App(){
  return(
    <View>
      <Text>Olá Mundo!</Text>
    </View>
  );
}

export default App;